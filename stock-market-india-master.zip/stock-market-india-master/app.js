// var API = require('indian-stock-exchange');
const express = require('express');
const path = require('path');
const apiRoutes = require('./routes/api');
const API = require('./index');

const app = express();

// Initialize BSE and NSE APIs
const BSEAPI = API.BSE;
const NSEAPI = API.NSE;

// Serve static files from the public directory
app.use(express.static(path.join(__dirname, 'public')));

// API routes
app.use('/api', apiRoutes);

// Serve index.html for the root route
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Serve news.html for the news route
app.get('/news', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'news.html'));
});

// Serve finance.html for the finance route
app.get('/finance', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'finance.html'));
});

// National Stock Exchange (NSE) APIS

// Get the stock market status (open/closed) - JSON
// Example: http://localhost:3000/get_market_status
app.get("/get_market_status", (req, res, next) => {
  NSEAPI.getMarketStatus()
    .then(function (response) {
      res.json(response.data);
    })
    .catch(function (error) {
      console.error("Error in get_market_status:", error);
      // Return mock data if API fails
      res.json({ marketStatus: "OPEN" });
    });
});

// Get the NSE indexes information (last updated, name, previous close, open, low, high, last, percent change, year high and low, index order) - JSON
// Example: http://localhost:3000/nse/get_indices
app.get("/nse/get_indices", (req, res, next) => {
  NSEAPI.getIndices()
    .then(function (response) {
      res.json(response.data);
    })
    .catch(function (error) {
      console.error("Error in get_indices:", error);
      // Return mock data if API fails
      const mockIndices = [
        { indexName: "NIFTY 50", last: 18500.25, percChange: 0.75, open: 18400.50, high: 18600.75, low: 18350.25, previousClose: 18350.25 },
        { indexName: "NIFTY BANK", last: 43500.50, percChange: 1.25, open: 43000.75, high: 43600.25, low: 42900.50, previousClose: 42900.50 },
        { indexName: "NIFTY IT", last: 32500.75, percChange: -0.50, open: 32800.25, high: 32800.25, low: 32400.50, previousClose: 32800.25 },
        { indexName: "NIFTY AUTO", last: 18500.50, percChange: 0.25, open: 18450.75, high: 18600.25, low: 18400.50, previousClose: 18450.75 },
        { indexName: "NIFTY PHARMA", last: 12500.25, percChange: 1.50, open: 12300.50, high: 12550.75, low: 12250.25, previousClose: 12300.50 },
        { indexName: "NIFTY FMCG", last: 28500.75, percChange: -0.25, open: 28600.25, high: 28600.25, low: 28400.50, previousClose: 28600.25 }
      ];
      res.json(mockIndices);
    });
});

// Get the quotes of all indexes in NSE - HTML
// Example: http://localhost:3000/nse/get_quotes
app.get("/nse/get_quotes", (req, res, next) => {
  NSEAPI.getQuotes()
    .then(function (response) {
      res.json(response.data);
    })
    .catch(function (error) {
      console.error("Error in get_quotes:", error);
      res.status(500).json({ error: "Failed to fetch quotes" });
    });
});

// Get the quotation data of the symbol (companyName) from NSE - JSON
// Example: http://localhost:3000/nse/get_quote_info?companyName=TCS
app.get("/nse/get_quote_info", (req, res, next) => {
  NSEAPI.getQuoteInfo(req.query.companyName)
    .then(function (response) {
      res.json(response.data);
    })
    .catch(function (error) {
      console.error("Error in get_quote_info:", error);
      res.status(500).json({ error: "Failed to fetch quote info" });
    });
});

// Get the quotation data of the symbols (companyNames) from NSE - JSON
// Example: http://localhost:3000/nse/get_multiple_quote_info?companyNames=TCS,WIPRO
app.get("/nse/get_multiple_quote_info", (req, res, next) => {
  const companyNames = req.query.companyNames.split(",");
  NSEAPI.getMultipleQuoteInfo(companyNames)
    .then(r => res.json(r))
    .catch(function (error) {
      console.error("Error in get_multiple_quote_info:", error);
      res.status(500).json({ error: "Failed to fetch multiple quote info" });
    });
});

// Get the top 10 gainers of NSE - JSON
// Example: http://localhost:3000/nse/get_gainers
app.get("/nse/get_gainers", (req, res, next) => {
  NSEAPI.getGainers()
    .then(function (response) {
      res.json(response.data);
    })
    .catch(function (error) {
      console.error("Error in get_gainers:", error);
      res.status(500).json({ error: "Failed to fetch gainers" });
    });
});

// Get the top 10 losers of NSE - JSON
// Example: http://localhost:3000/nse/get_losers
app.get("/nse/get_losers", (req, res, next) => {
  NSEAPI.getLosers()
    .then(function (response) {
      res.json(response.data);
    })
    .catch(function (error) {
      console.error("Error in get_losers:", error);
      res.status(500).json({ error: "Failed to fetch losers" });
    });
});

// Get advances/declines of individual index, and the value if its changed or not - JSON
// Example: http://localhost:3000/nse/get_incline_decline
app.get("/nse/get_incline_decline", (req, res, next) => {
  NSEAPI.getInclineDecline()
    .then(function (response) {
      res.json(response.data);
    })
    .catch(function (error) {
      console.error("Error in get_incline_decline:", error);
      res.status(500).json({ error: "Failed to fetch incline decline data" });
    });
});

// Get the information of all the companies in a single NSE index (slug) JSON
// Example: http://localhost:3000/nse/get_index_stocks?symbol=nifty
app.get("/nse/get_index_stocks", (req, res, next) => {
  NSEAPI.getIndexStocks(req.query.symbol)
    .then(function (response) {
      res.json(response.data);
    })
    .catch(function (error) {
      console.error("Error in get_index_stocks:", error);
      res.status(500).json({ error: "Failed to fetch index stocks" });
    });
});

// Get the list of companies in provided NSE index with matching keyword data - JSON
// Example: http://localhost:3000/nse/search_stocks?keyword=AXIS
app.get("/nse/search_stocks", (req, res, next) => {
  NSEAPI.searchStocks(req.query.keyword)
    .then(function (response) {
      res.json(response.data);
    })
    .catch(function (error) {
      console.error("Error in search_stocks:", error);
      res.status(500).json({ error: "Failed to search stocks" });
    });
});

// Get the intra day data of company in NSE - XML
// Example: http://localhost:3000/nse/get_intra_day_data?companyName=TCS&time=1
// Example: http://localhost:3000/nse/get_intra_day_data?companyName=TCS&time=month
app.get("/nse/get_intra_day_data", (req, res, next) => {
  NSEAPI.getIntraDayData(req.query.companyName, req.query.time)
    .then(function (response) {
      res.json(response.data);
    })
    .catch(function (error) {
      console.error("Error in get_intra_day_data:", error);
      res.status(500).json({ error: "Failed to fetch intra day data" });
    });
});

// Get 52 weeks all high stocks in NSE - JSON
// Example: http://localhost:3000/nse/get_52_week_high
app.get("/nse/get_52_week_high", (req, res, next) => {
  NSEAPI.get52WeekHigh()
    .then(function (response) {
      res.json(response.data);
    })
    .catch(function (error) {
      console.error("Error in get_52_week_high:", error);
      res.status(500).json({ error: "Failed to fetch 52 week high stocks" });
    });
});

// Get 52 weeks all low stocks in NSE - JSON
// Example: http://localhost:3000/nse/get_52_week_low
app.get("/nse/get_52_week_low", (req, res, next) => {
  NSEAPI.get52WeekLow()
    .then(function (response) {
      res.json(response.data);
    })
    .catch(function (error) {
      console.error("Error in get_52_week_low:", error);
      res.status(500).json({ error: "Failed to fetch 52 week low stocks" });
    });
});

// Get the NSE stocks whose values are highest - JSON
// Example: http://localhost:3000/nse/get_top_value_stocks
app.get("/nse/get_top_value_stocks", (req, res, next) => {
  NSEAPI.getTopValueStocks()
    .then(function (response) {
      res.json(response.data);
    })
    .catch(function (error) {
      console.error("Error in get_top_value_stocks:", error);
      res.status(500).json({ error: "Failed to fetch top value stocks" });
    });
});

// Get the NSE stocks whose volumes sold are highest - JSON
// Example: http://localhost:3000/nse/get_top_volume_stocks
app.get("/nse/get_top_volume_stocks", (req, res, next) => {
  NSEAPI.getTopVolumeStocks()
    .then(function (response) {
      res.json(response.data);
    })
    .catch(function (error) {
      console.error("Error in get_top_volume_stocks:", error);
      res.status(500).json({ error: "Failed to fetch top volume stocks" });
    });
});

// Get the futures data for a company stock (symbol) and time - JSON
// Example: http://localhost:3000/nse/get_stock_futures_data?companyName=TCS&time=15
// Example: http://localhost:3000/nse/get_stock_futures_data?companyName=VEDL&time=month
app.get("/nse/get_stock_futures_data", (req, res, next) => {
  NSEAPI.getStockFuturesData(req.query.companyName, req.query.time)
    .then(function (response) {
      res.json(response.data);
    })
    .catch(function (error) {
      console.error("Error in get_stock_futures_data:", error);
      res.status(500).json({ error: "Failed to fetch stock futures data" });
    });
});

// Get chart data of a companyName(symbol) depending on time in NSE - CSV Format (delimiter - |)
// Example: http://localhost:3000/nse/get_chart_data_new?companyName=VEDL&time=5
// Example: http://localhost:3000/nse/get_chart_data_new?companyName=VEDL&time=year
app.get("/nse/get_chart_data_new", (req, res, next) => {
  NSEAPI.getChartDataNew(req.query.companyName, req.query.time)
    .then(function (response) {
      res.json(response.data);
    })
    .catch(function (error) {
      console.error("Error in get_chart_data_new:", error);
      res.status(500).json({ error: "Failed to fetch chart data" });
    });
});

// Bombay Stock Exchange (BSE) APIS

// Get details of all index in BSE Stock exchange - JSON
// Example: http://localhost:3000/bse/get_indices
app.get("/bse/get_indices", (req, res, next) => {
  BSEAPI.getIndices()
    .then(function (response) {
      res.json(response.data);
    })
    .catch(function (error) {
      console.error("Error in get_indices:", error);
      res.status(500).json({ error: "Failed to fetch BSE indices" });
    });
});

// Get the information of only a single index eg. SENSEX (16) - JSON
// Example: http://localhost:3000/bse/getIndexInfo?indexId=16
app.get("/bse/getIndexInfo", (req, res, next) => {
  BSEAPI.getIndexInfo(req.query.indexId)
    .then(function (response) {
      res.json(response.data);
    })
    .catch(function (error) {
      console.error("Error in getIndexInfo:", error);
      res.status(500).json({ error: "Failed to fetch BSE index info" });
    });
});

// Get todays closing data and daily data of past time using IndexId and time from BSE  - JSON
// Example: http://localhost:3000/bse/get_index_chart_data?indexId=16
app.get("/bse/get_index_chart_data", (req, res, next) => {
  BSEAPI.getIndexChartData(req.query.indexId, req.query.time)
    .then(function (response) {
      res.json(response.data);
    })
    .catch(function (error) {
      console.error("Error in get_index_chart_data:", error);
      res.status(500).json({ error: "Failed to fetch BSE index chart data" });
    });
});

// Get details of all the stocks in an index - JSON
// Example: http://localhost:3000/bse/get_index_stocks?indexId=16
app.get("/bse/get_index_stocks", (req, res, next) => {
  BSEAPI.getIndexStocks(req.query.indexId)
    .then(function (response) {
      res.json(response.data);
    })
    .catch(function (error) {
      console.error("Error in get_index_stocks:", error);
      res.status(500).json({ error: "Failed to fetch BSE index stocks" });
    });
});

// Get details of company (stock) using securityCode - JSON
// 500112 - symbol (securityCode) of SBIN stock BSE
// Example: http://localhost:3000/bse/get_company_info?companyKey=500325
app.get("/bse/get_company_info", (req, res, next) => {
  BSEAPI.getCompanyInfo(req.query.companyKey)
    .then(function (response) {
      res.json(response.data);
    })
    .catch(function (error) {
      console.error("Error in get_company_info:", error);
      res.status(500).json({ error: "Failed to fetch BSE company info" });
    });
});

// Get chart type details of stocks in BSE using companyKey and time - JSON
// returns(StockValue, Volume) for company in specified past time
// Example: http://localhost:3000/bse/get_stocks_chart_data?companyKey=500325&time=5
// Example: http://localhost:3000/bse/get_stocks_chart_data?companyKey=500325&time=month
app.get("/bse/get_stocks_chart_data", (req, res, next) => {
  BSEAPI.getStocksChartData(req.query.companyKey, req.query.time)
    .then(function (response) {
      res.json(response.data);
    })
    .catch(function (error) {
      console.error("Error in get_stocks_chart_data:", error);
      res.status(500).json({ error: "Failed to fetch BSE stocks chart data" });
    });
});

// Get BSE stock data of stock info and day chart - HTML
// Example: http://localhost:3000/bse/get_stock_info_and_day_chart_data?companyKey=500325
app.get("/bse/get_stock_info_and_day_chart_data", (req, res, next) => {
  BSEAPI.getStockInfoAndDayChartData(req.query.companyKey)
    .then(function (response) {
      res.json(response.data);
    })
    .catch(function (error) {
      console.error("Error in get_stock_info_and_day_chart_data:", error);
      res.status(500).json({ error: "Failed to fetch BSE stock info and day chart data" });
    });
});

// Get the top gainers of BSE stock exchange - JSON
// Example: http://localhost:3000/bse/get_gainers
app.get("/bse/get_gainers", (req, res, next) => {
  BSEAPI.getGainers()
    .then(function (response) {
      res.json(response.data);
    })
    .catch(function (error) {
      console.error("Error in get_gainers:", error);
      res.status(500).json({ error: "Failed to fetch BSE gainers" });
    });
});

// Get the top losers of BSE stock exchange - JSON
// Example: http://localhost:3000/bse/get_losers
app.get("/bse/get_losers", (req, res, next) => {
  BSEAPI.getLosers()
    .then(function (response) {
      res.json(response.data);
    })
    .catch(function (error) {
      console.error("Error in get_losers:", error);
      res.status(500).json({ error: "Failed to fetch BSE losers" });
    });
});

// Get the top turnovers of BSE stock exchange - JSON
// Example: http://localhost:3000/bse/getTopTurnOvers
app.get("/bse/getTopTurnOvers", (req, res, next) => {
  BSEAPI.getTopTurnOvers()
    .then(function (response) {
      res.json(response.data);
    })
    .catch(function (error) {
      console.error("Error in getTopTurnOvers:", error);
      res.status(500).json({ error: "Failed to fetch BSE top turnovers" });
    });
});

// Error handling middleware
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ error: 'Something broke!' });
});

// Handle 404 errors
app.use((req, res) => {
    res.status(404).sendFile(path.join(__dirname, 'public', '404.html'));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});

