const express = require('express');
const router = express.Router();
const axios = require('axios');

// Stock history endpoint
router.get('/stock-history', async (req, res) => {
    try {
        const { symbol, period } = req.query;
        // Generate more realistic mock data
        const data = generateMockStockHistory(symbol, period);
        res.json(data);
    } catch (error) {
        console.error('Error fetching stock history:', error);
        res.status(500).json({ error: 'Failed to fetch stock history' });
    }
});

// Search endpoint
router.get('/search', async (req, res) => {
    try {
        const { q } = req.query;
        // Return more comprehensive mock search results
        const results = generateMockSearchResults(q);
        res.json(results);
    } catch (error) {
        console.error('Error searching:', error);
        res.status(500).json({ error: 'Search failed' });
    }
});

// News endpoint
router.get('/news', async (req, res) => {
    try {
        // Return more realistic mock news
        const news = generateMockNews();
        res.json(news);
    } catch (error) {
        console.error('Error fetching news:', error);
        res.status(500).json({ error: 'Failed to fetch news' });
    }
});

// Stocks endpoint for finance page
router.get('/stocks', async (req, res) => {
    try {
        const stocks = generateMockStocks();
        res.json(stocks);
    } catch (error) {
        console.error('Error fetching stocks:', error);
        res.status(500).json({ error: 'Failed to fetch stocks' });
    }
});

// Mutual funds endpoint for finance page
router.get('/mutual-funds', async (req, res) => {
    try {
        const mutualFunds = generateMockMutualFunds();
        res.json(mutualFunds);
    } catch (error) {
        console.error('Error fetching mutual funds:', error);
        res.status(500).json({ error: 'Failed to fetch mutual funds' });
    }
});

// ETFs endpoint for finance page
router.get('/etfs', async (req, res) => {
    try {
        const etfs = generateMockETFs();
        res.json(etfs);
    } catch (error) {
        console.error('Error fetching ETFs:', error);
        res.status(500).json({ error: 'Failed to fetch ETFs' });
    }
});

// Commodities endpoint for finance page
router.get('/commodities', async (req, res) => {
    try {
        const commodities = generateMockCommodities();
        res.json(commodities);
    } catch (error) {
        console.error('Error fetching commodities:', error);
        res.status(500).json({ error: 'Failed to fetch commodities' });
    }
});

// Forex endpoint for finance page
router.get('/forex', async (req, res) => {
    try {
        const forex = generateMockForex();
        res.json(forex);
    } catch (error) {
        console.error('Error fetching forex:', error);
        res.status(500).json({ error: 'Failed to fetch forex' });
    }
});

// Insider trading endpoint for finance page
router.get('/insider-trading', async (req, res) => {
    try {
        // Get filter parameters
        const { stock, date, party, category, txnType } = req.query;
        
        // Generate dynamic data with current time
        const insiderTradingData = generateMockInsiderTradingData();
        
        // Apply filters if provided
        let filteredData = insiderTradingData;
        if (stock || date || party || category || txnType) {
            filteredData = insiderTradingData.filter(item => {
                return (
                    (!stock || item.stock.toLowerCase().includes(stock.toLowerCase())) &&
                    (!date || item.date.toLowerCase().includes(date.toLowerCase())) &&
                    (!party || item.party.toLowerCase().includes(party.toLowerCase())) &&
                    (!category || item.category === category) &&
                    (!txnType || item.txnType === txnType)
                );
            });
        }
        
        res.json(filteredData);
    } catch (error) {
        console.error('Error fetching insider trading data:', error);
        res.status(500).json({ error: 'Failed to fetch insider trading data' });
    }
});

// Helper functions for mock data
function generateMockStockHistory(symbol, period) {
    const now = new Date();
    const data = {
        timestamps: [],
        prices: [],
        min: Infinity,
        max: -Infinity
    };

    let intervals;
    let basePrice;
    
    // Set different base prices for different symbols
    switch (symbol) {
        case 'NIFTY 50':
            basePrice = 18500;
            break;
        case 'NIFTY BANK':
            basePrice = 43500;
            break;
        case 'NIFTY IT':
            basePrice = 32500;
            break;
        case 'NIFTY AUTO':
            basePrice = 18500;
            break;
        case 'NIFTY PHARMA':
            basePrice = 12500;
            break;
        case 'NIFTY FMCG':
            basePrice = 28500;
            break;
        case 'RELIANCE':
            basePrice = 2750;
            break;
        case 'TCS':
            basePrice = 3850;
            break;
        case 'HDFCBANK':
            basePrice = 1650;
            break;
        case 'INFY':
            basePrice = 1450;
            break;
        case 'ICICIBANK':
            basePrice = 950;
            break;
        case 'HINDUNILVR':
            basePrice = 2450;
            break;
        case 'ITC':
            basePrice = 425;
            break;
        case 'SBIN':
            basePrice = 650;
            break;
        case 'BHARTIARTL':
            basePrice = 1150;
            break;
        case 'KOTAKBANK':
            basePrice = 1750;
            break;
        default:
            basePrice = 1000 + Math.random() * 9000;
    }

    switch (period) {
        case '1D':
            intervals = 24;
            // For 1D, use hourly data
            for (let i = 0; i < intervals; i++) {
                const timestamp = new Date(now);
                timestamp.setHours(now.getHours() - (intervals - i));
                const price = basePrice + (Math.random() - 0.5) * 200;
                
                data.timestamps.push(timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
                data.prices.push(price);
                
                data.min = Math.min(data.min, price);
                data.max = Math.max(data.max, price);
            }
            break;
        case '5D':
            intervals = 5;
            // For 5D, use daily data
            for (let i = 0; i < intervals; i++) {
                const timestamp = new Date(now);
                timestamp.setDate(now.getDate() - (intervals - i));
                const price = basePrice + (Math.random() - 0.5) * 500;
                
                data.timestamps.push(timestamp.toLocaleDateString([], { weekday: 'short' }));
                data.prices.push(price);
                
                data.min = Math.min(data.min, price);
                data.max = Math.max(data.max, price);
            }
            break;
        case '1M':
            intervals = 30;
            // For 1M, use daily data
            for (let i = 0; i < intervals; i++) {
                const timestamp = new Date(now);
                timestamp.setDate(now.getDate() - (intervals - i));
                const price = basePrice + (Math.random() - 0.5) * 1000;
                
                data.timestamps.push(timestamp.toLocaleDateString([], { month: 'short', day: 'numeric' }));
                data.prices.push(price);
                
                data.min = Math.min(data.min, price);
                data.max = Math.max(data.max, price);
            }
            break;
        case 'YTD':
            intervals = Math.floor((now - new Date(now.getFullYear(), 0, 1)) / (1000 * 60 * 60 * 24));
            // For YTD, use weekly data
            for (let i = 0; i < intervals; i += 7) {
                const timestamp = new Date(now);
                timestamp.setDate(now.getDate() - (intervals - i));
                const price = basePrice + (Math.random() - 0.5) * 2000;
                
                data.timestamps.push(timestamp.toLocaleDateString([], { month: 'short', day: 'numeric' }));
                data.prices.push(price);
                
                data.min = Math.min(data.min, price);
                data.max = Math.max(data.max, price);
            }
            break;
        case '1Y':
            intervals = 12;
            // For 1Y, use monthly data
            for (let i = 0; i < intervals; i++) {
                const timestamp = new Date(now);
                timestamp.setMonth(now.getMonth() - (intervals - i));
                const price = basePrice + (Math.random() - 0.5) * 3000;
                
                data.timestamps.push(timestamp.toLocaleDateString([], { month: 'short' }));
                data.prices.push(price);
                
                data.min = Math.min(data.min, price);
                data.max = Math.max(data.max, price);
            }
            break;
        case '5Y':
            intervals = 5;
            // For 5Y, use yearly data
            for (let i = 0; i < intervals; i++) {
                const timestamp = new Date(now);
                timestamp.setFullYear(now.getFullYear() - (intervals - i));
                const price = basePrice + (Math.random() - 0.5) * 5000;
                
                data.timestamps.push(timestamp.getFullYear().toString());
                data.prices.push(price);
                
                data.min = Math.min(data.min, price);
                data.max = Math.max(data.max, price);
            }
            break;
        default:
            intervals = 24;
            // Default to hourly data
            for (let i = 0; i < intervals; i++) {
                const timestamp = new Date(now);
                timestamp.setHours(now.getHours() - (intervals - i));
                const price = basePrice + (Math.random() - 0.5) * 200;
                
                data.timestamps.push(timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
                data.prices.push(price);
                
                data.min = Math.min(data.min, price);
                data.max = Math.max(data.max, price);
            }
    }

    return data;
}

function generateMockSearchResults(query) {
    const mockStocks = [
        { symbol: 'RELIANCE', name: 'Reliance Industries Ltd.' },
        { symbol: 'TCS', name: 'Tata Consultancy Services Ltd.' },
        { symbol: 'HDFCBANK', name: 'HDFC Bank Ltd.' },
        { symbol: 'INFY', name: 'Infosys Ltd.' },
        { symbol: 'ICICIBANK', name: 'ICICI Bank Ltd.' },
        { symbol: 'HINDUNILVR', name: 'Hindustan Unilever Ltd.' },
        { symbol: 'ITC', name: 'ITC Ltd.' },
        { symbol: 'SBIN', name: 'State Bank of India' },
        { symbol: 'BHARTIARTL', name: 'Bharti Airtel Ltd.' },
        { symbol: 'KOTAKBANK', name: 'Kotak Mahindra Bank Ltd.' },
        { symbol: 'ASIANPAINT', name: 'Asian Paints Ltd.' },
        { symbol: 'AXISBANK', name: 'Axis Bank Ltd.' },
        { symbol: 'BAJFINANCE', name: 'Bajaj Finance Ltd.' },
        { symbol: 'BAJAJFINSV', name: 'Bajaj Finserv Ltd.' },
        { symbol: 'BRITANNIA', name: 'Britannia Industries Ltd.' },
        { symbol: 'CIPLA', name: 'Cipla Ltd.' },
        { symbol: 'COALINDIA', name: 'Coal India Ltd.' },
        { symbol: 'DIVISLAB', name: 'Divis Laboratories Ltd.' },
        { symbol: 'DRREDDY', name: 'Dr. Reddy\'s Laboratories Ltd.' },
        { symbol: 'EICHERMOT', name: 'Eicher Motors Ltd.' },
        { symbol: 'GRASIM', name: 'Grasim Industries Ltd.' },
        { symbol: 'HCLTECH', name: 'HCL Technologies Ltd.' },
        { symbol: 'HEROMOTOCO', name: 'Hero MotoCorp Ltd.' },
        { symbol: 'HINDALCO', name: 'Hindalco Industries Ltd.' },
        { symbol: 'JSWSTEEL', name: 'JSW Steel Ltd.' },
        { symbol: 'LT', name: 'Larsen & Toubro Ltd.' },
        { symbol: 'M&M', name: 'Mahindra & Mahindra Ltd.' },
        { symbol: 'MARUTI', name: 'Maruti Suzuki India Ltd.' },
        { symbol: 'NTPC', name: 'NTPC Ltd.' },
        { symbol: 'ONGC', name: 'Oil & Natural Gas Corporation Ltd.' },
        { symbol: 'POWERGRID', name: 'Power Grid Corporation of India Ltd.' },
        { symbol: 'SUNPHARMA', name: 'Sun Pharmaceutical Industries Ltd.' },
        { symbol: 'TATAMOTORS', name: 'Tata Motors Ltd.' },
        { symbol: 'TATASTEEL', name: 'Tata Steel Ltd.' },
        { symbol: 'TECHM', name: 'Tech Mahindra Ltd.' },
        { symbol: 'TITAN', name: 'Titan Company Ltd.' },
        { symbol: 'ULTRACEMCO', name: 'UltraTech Cement Ltd.' },
        { symbol: 'WIPRO', name: 'Wipro Ltd.' }
    ];

    return mockStocks.filter(stock => 
        stock.symbol.toLowerCase().includes(query.toLowerCase()) ||
        stock.name.toLowerCase().includes(query.toLowerCase())
    );
}

function generateMockNews() {
    return [
        {
            title: 'Indian markets close higher as banking stocks surge',
            summary: 'The Indian stock market ended on a positive note with banking stocks leading the gains. The NIFTY 50 index closed at 19,425.35, up 0.75% from the previous close.',
            source: 'Financial Express',
            date: '45 minutes ago',
            image: 'https://public.readdy.ai/ai/img_res/0143d70c293c5e0afdfadda349367eff.jpg',
            url: '#'
        },
        {
            title: 'NIFTY 50 hits new all-time high as foreign investors continue buying',
            summary: 'The benchmark index reached new heights as foreign institutional investors maintained their buying spree. The index touched 19,500 for the first time in history.',
            source: 'Economic Times',
            date: '1 hour ago',
            image: 'https://public.readdy.ai/ai/img_res/f81689b917dbc00b8f5b479593a23272.jpg',
            url: '#'
        },
        {
            title: 'Global stock markets rally as inflation concerns ease',
            summary: 'Markets worldwide showed positive momentum as inflation data came in better than expected. The US Federal Reserve\'s dovish stance also contributed to the rally.',
            source: 'Business Standard',
            date: '90 minutes ago',
            image: 'https://public.readdy.ai/ai/img_res/96e1c0e10b90789c277bd263942c4e67.jpg',
            url: '#'
        },
        {
            title: 'RBI policy decision will impact market sentiment, say experts',
            summary: 'The Reserve Bank of India\'s monetary policy committee is expected to maintain the status quo on interest rates, which could provide further support to the equity markets.',
            source: 'Reuters Finance',
            date: '2 hours ago',
            image: 'https://public.readdy.ai/ai/img_res/f020da81fc76aa4e344523ae4c9c01df.jpg',
            url: '#'
        },
        {
            title: 'Tech stocks lead gains in Asian markets',
            summary: 'Technology stocks across Asian markets surged as investors bet on continued growth in the sector. Indian IT stocks also participated in the rally.',
            source: 'Bloomberg',
            date: '3 hours ago',
            image: 'https://public.readdy.ai/ai/img_res/f8604ab9c11adcdd66870af29cbc2ef7.jpg',
            url: '#'
        },
        {
            title: 'Oil prices rise amid supply concerns',
            summary: 'Crude oil prices climbed higher as concerns about supply disruptions in the Middle East persisted. This could impact inflation and central bank policies globally.',
            source: 'CNBC',
            date: '4 hours ago',
            image: 'https://public.readdy.ai/ai/img_res/0143d70c293c5e0afdfadda349367eff.jpg',
            url: '#'
        }
    ];
}

function generateMockStocks() {
    const stocks = [
        { symbol: 'RELIANCE', name: 'Reliance Industries Ltd.', price: 2750.25, change: 1.25, open: 2720.50, high: 2760.75, low: 2715.25, volume: '2.5M' },
        { symbol: 'TCS', name: 'Tata Consultancy Services Ltd.', price: 3850.75, change: -0.75, open: 3880.25, high: 3880.25, low: 3840.50, volume: '1.2M' },
        { symbol: 'HDFCBANK', name: 'HDFC Bank Ltd.', price: 1650.50, change: 0.50, open: 1645.25, high: 1655.75, low: 1640.25, volume: '3.1M' },
        { symbol: 'INFY', name: 'Infosys Ltd.', price: 1450.25, change: -0.25, open: 1455.75, high: 1455.75, low: 1445.50, volume: '1.8M' },
        { symbol: 'ICICIBANK', name: 'ICICI Bank Ltd.', price: 950.75, change: 1.75, open: 935.25, high: 955.50, low: 930.75, volume: '4.2M' },
        { symbol: 'HINDUNILVR', name: 'Hindustan Unilever Ltd.', price: 2450.50, change: 0.25, open: 2445.75, high: 2455.25, low: 2440.50, volume: '0.9M' },
        { symbol: 'ITC', name: 'ITC Ltd.', price: 425.25, change: -0.50, open: 427.50, high: 427.50, low: 424.25, volume: '2.7M' },
        { symbol: 'SBIN', name: 'State Bank of India', price: 650.75, change: 1.00, open: 645.25, high: 652.50, low: 644.75, volume: '5.3M' },
        { symbol: 'BHARTIARTL', name: 'Bharti Airtel Ltd.', price: 1150.25, change: 0.75, open: 1142.50, high: 1152.75, low: 1140.25, volume: '3.8M' },
        { symbol: 'KOTAKBANK', name: 'Kotak Mahindra Bank Ltd.', price: 1750.50, change: -0.25, open: 1755.25, high: 1755.25, low: 1745.75, volume: '1.5M' }
    ];
    
    return stocks;
}

function generateMockMutualFunds() {
    const mutualFunds = [
        { symbol: 'HDFCMF', name: 'HDFC Mid-Cap Fund', price: 45.25, change: 0.75, open: 45.00, high: 45.50, low: 44.75, volume: 'NA' },
        { symbol: 'ICICIPRU', name: 'ICICI Prudential Bluechip Fund', price: 65.50, change: 0.50, open: 65.25, high: 65.75, low: 65.00, volume: 'NA' },
        { symbol: 'SBIEMF', name: 'SBI Emerging Businesses Fund', price: 85.75, change: 1.25, open: 84.50, high: 86.00, low: 84.25, volume: 'NA' },
        { symbol: 'AXISMF', name: 'Axis Bluechip Fund', price: 35.25, change: -0.25, open: 35.50, high: 35.50, low: 35.00, volume: 'NA' },
        { symbol: 'MIRAEAMF', name: 'Mirae Asset Emerging Bluechip Fund', price: 55.75, change: 0.25, open: 55.50, high: 56.00, low: 55.25, volume: 'NA' },
        { symbol: 'NIPPONMF', name: 'Nippon India Large Cap Fund', price: 75.50, change: 0.75, open: 75.00, high: 75.75, low: 74.75, volume: 'NA' },
        { symbol: 'KOTAKMF', name: 'Kotak Emerging Equity Fund', price: 95.25, change: 1.00, open: 94.25, high: 95.50, low: 94.00, volume: 'NA' },
        { symbol: 'ADITYAMF', name: 'Aditya Birla Sun Life Frontline Equity Fund', price: 65.75, change: -0.50, open: 66.25, high: 66.25, low: 65.50, volume: 'NA' },
        { symbol: 'TATAMF', name: 'Tata Large Cap Fund', price: 45.50, change: 0.25, open: 45.25, high: 45.75, low: 45.00, volume: 'NA' },
        { symbol: 'UTIMF', name: 'UTI Nifty Index Fund', price: 25.75, change: 0.50, open: 25.25, high: 26.00, low: 25.00, volume: 'NA' }
    ];
    
    return mutualFunds;
}

function generateMockETFs() {
    const etfs = [
        { symbol: 'NIFTYBEES', name: 'Nippon India ETF Nifty BeES', price: 185.25, change: 0.75, open: 184.50, high: 185.50, low: 184.25, volume: '1.2M' },
        { symbol: 'BANKBEES', name: 'Nippon India ETF Bank BeES', price: 435.50, change: 1.25, open: 430.75, high: 436.25, low: 430.25, volume: '0.8M' },
        { symbol: 'JUNIORBEES', name: 'Nippon India ETF Nifty Next 50', price: 325.75, change: -0.50, open: 328.25, high: 328.25, low: 324.50, volume: '0.5M' },
        { symbol: 'GOLDBEES', name: 'Nippon India ETF Gold BeES', price: 55.25, change: 0.25, open: 55.00, high: 55.50, low: 54.75, volume: '1.5M' },
        { symbol: 'NETFIT', name: 'Nippon India ETF Nifty IT', price: 425.50, change: -0.75, open: 427.50, high: 427.50, low: 424.25, volume: '0.3M' },
        { symbol: 'NETFPHARMA', name: 'Nippon India ETF Nifty Pharma', price: 125.75, change: 1.50, open: 123.50, high: 126.50, low: 123.25, volume: '0.4M' },
        { symbol: 'NETFFMCG', name: 'Nippon India ETF Nifty FMCG', price: 285.25, change: -0.25, open: 286.25, high: 286.25, low: 284.50, volume: '0.2M' },
        { symbol: 'NETFAUTO', name: 'Nippon India ETF Nifty Auto', price: 185.50, change: 0.25, open: 184.50, high: 186.25, low: 184.25, volume: '0.6M' },
        { symbol: 'NETFMETAL', name: 'Nippon India ETF Nifty Metal', price: 225.75, change: 1.00, open: 224.25, high: 226.50, low: 224.00, volume: '0.3M' },
        { symbol: 'NETFREALTY', name: 'Nippon India ETF Nifty Realty', price: 85.50, change: -0.50, open: 86.25, high: 86.25, low: 85.25, volume: '0.4M' }
    ];
    
    return etfs;
}

function generateMockCommodities() {
    const commodities = [
        { symbol: 'GOLD', name: 'Gold', price: 59250.25, change: 0.75, open: 59200.50, high: 59300.75, low: 59150.25, volume: 'NA' },
        { symbol: 'SILVER', name: 'Silver', price: 72500.50, change: 1.25, open: 72000.75, high: 72600.25, low: 71900.50, volume: 'NA' },
        { symbol: 'CRUDE', name: 'Crude Oil', price: 6250.75, change: -0.50, open: 6280.25, high: 6280.25, low: 6240.50, volume: 'NA' },
        { symbol: 'NATURALGAS', name: 'Natural Gas', price: 225.25, change: 0.25, open: 224.50, high: 225.50, low: 224.25, volume: 'NA' },
        { symbol: 'COPPER', name: 'Copper', price: 725.50, change: 1.75, open: 715.25, high: 726.50, low: 714.75, volume: 'NA' },
        { symbol: 'ZINC', name: 'Zinc', price: 225.75, change: -0.25, open: 226.50, high: 226.50, low: 225.25, volume: 'NA' },
        { symbol: 'LEAD', name: 'Lead', price: 185.25, change: 0.50, open: 184.50, high: 185.50, low: 184.25, volume: 'NA' },
        { symbol: 'NICKEL', name: 'Nickel', price: 1250.50, change: 1.00, open: 1240.25, high: 1252.50, low: 1239.75, volume: 'NA' },
        { symbol: 'ALUMINIUM', name: 'Aluminium', price: 185.75, change: -0.75, open: 187.25, high: 187.25, low: 185.50, volume: 'NA' },
        { symbol: 'COTTON', name: 'Cotton', price: 62500.25, change: 0.25, open: 62450.75, high: 62550.25, low: 62400.50, volume: 'NA' }
    ];
    
    return commodities;
}

function generateMockForex() {
    const forex = [
        { symbol: 'USDINR', name: 'US Dollar / Indian Rupee', price: 82.75, change: -0.25, open: 83.00, high: 83.00, low: 82.50, volume: 'NA' },
        { symbol: 'EURINR', name: 'Euro / Indian Rupee', price: 90.25, change: 0.50, open: 89.75, high: 90.50, low: 89.50, volume: 'NA' },
        { symbol: 'GBPINR', name: 'British Pound / Indian Rupee', price: 105.50, change: -0.75, open: 106.25, high: 106.25, low: 105.25, volume: 'NA' },
        { symbol: 'JPYINR', name: 'Japanese Yen / Indian Rupee', price: 0.58, change: 0.25, open: 0.57, high: 0.59, low: 0.57, volume: 'NA' },
        { symbol: 'AUDINR', name: 'Australian Dollar / Indian Rupee', price: 55.75, change: 1.00, open: 55.25, high: 56.00, low: 55.00, volume: 'NA' },
        { symbol: 'CADINR', name: 'Canadian Dollar / Indian Rupee', price: 62.25, change: -0.50, open: 62.75, high: 62.75, low: 62.00, volume: 'NA' },
        { symbol: 'CHFINR', name: 'Swiss Franc / Indian Rupee', price: 92.50, change: 0.25, open: 92.25, high: 92.75, low: 92.00, volume: 'NA' },
        { symbol: 'SGDINR', name: 'Singapore Dollar / Indian Rupee', price: 61.75, change: -0.25, open: 62.00, high: 62.00, low: 61.50, volume: 'NA' },
        { symbol: 'HKDINR', name: 'Hong Kong Dollar / Indian Rupee', price: 10.50, change: 0.00, open: 10.50, high: 10.50, low: 10.50, volume: 'NA' },
        { symbol: 'CNYINR', name: 'Chinese Yuan / Indian Rupee', price: 11.25, change: 0.75, open: 11.17, high: 11.30, low: 11.15, volume: 'NA' }
    ];
    
    return forex;
}

function generateMockInsiderTradingData() {
    // Base data for consistency
    const baseData = [
        {
            stock: 'PIDILITIND',
            date: getCurrentDate(),
            party: 'Saswata Dhar',
            category: 'Insider - Employee',
            txnType: 'Buy',
            avgPrice: 1.00,
            valueTraded: '900.00',
            holdingsChange: '~ 0.00%',
            quantity: '900.00'
        },
        {
            stock: 'GOACARBON',
            date: getCurrentDate(),
            party: 'Silver Line Ventures Private Limited',
            category: 'Bulk',
            txnType: 'Buy',
            avgPrice: 510.49,
            valueTraded: '2.74Cr',
            holdingsChange: '0.59%',
            quantity: '53.77K'
        },
        {
            stock: 'FINCABLES',
            date: getCurrentDate(),
            party: 'Graviton Research Capital Llp',
            category: 'Bulk',
            txnType: 'Sell',
            avgPrice: 953.94,
            valueTraded: '93.72Cr',
            holdingsChange: '0.64%',
            quantity: '9.82L'
        },
        {
            stock: 'AMBEY',
            date: getCurrentDate(),
            party: 'Sbj Bpo Services Limited',
            category: 'Bulk',
            txnType: 'Buy',
            avgPrice: 42.67,
            valueTraded: '59.74L',
            holdingsChange: '0.75%',
            quantity: '1.40L'
        },
        {
            stock: 'GLENMARK',
            date: getCurrentDate(),
            party: 'Integrated Core Strategies (asia) Pte',
            category: 'Block',
            txnType: 'Buy',
            avgPrice: 1492.65,
            valueTraded: '39.48Cr',
            holdingsChange: '0.09%',
            quantity: '2.64L'
        },
        {
            stock: 'ADMANUM',
            date: getCurrentDate(),
            party: 'Neha Ravindrakumar Shethwala',
            category: 'Bulk',
            txnType: 'Sell',
            avgPrice: 67.00,
            valueTraded: '62.31L',
            holdingsChange: '1.24%',
            quantity: '93.00K'
        },
        {
            stock: 'VLEGOV',
            date: getCurrentDate(),
            party: 'Nishant Pitti',
            category: 'Bulk',
            txnType: 'Buy',
            avgPrice: 37.18,
            valueTraded: '3.52Cr',
            holdingsChange: '0.89%',
            quantity: '9.46L'
        },
        {
            stock: 'VINEETLAB',
            date: getCurrentDate(),
            party: 'Chaubara Eats Private Limited',
            category: 'Bulk',
            txnType: 'Buy',
            avgPrice: 35.52,
            valueTraded: '25.98L',
            holdingsChange: '0.79%',
            quantity: '73.13K'
        },
        {
            stock: 'PARAMOUNT',
            date: getCurrentDate(),
            party: 'Swatipushp Tradelink Private Limited',
            category: 'Bulk',
            txnType: 'Sell',
            avgPrice: 49.02,
            valueTraded: '51.18L',
            holdingsChange: '2.31%',
            quantity: '1.04L'
        },
        {
            stock: 'OLIL',
            date: getCurrentDate(),
            party: 'Girish V Bhatt Huf',
            category: 'Bulk',
            txnType: 'Buy',
            avgPrice: 145.40,
            valueTraded: '52.34L',
            holdingsChange: '1.00%',
            quantity: '36.00K'
        },
        {
            stock: 'ONDOOR',
            date: getCurrentDate(),
            party: 'Anant Wealth Consultants Private Limited',
            category: 'Bulk',
            txnType: 'Sell',
            avgPrice: 160.91,
            valueTraded: '46.34L',
            holdingsChange: '0.51%',
            quantity: '28.80K'
        }
    ];
    
    // Add dynamic data for the first few entries to simulate live updates
    const dynamicStocks = [
        { 
            stock: 'RELIANCE', 
            party: 'Reliance Retail Ventures Limited',
            category: 'Bulk',
            valueTraded: randomizeCrValue(45, 65),
            quantity: randomizeLValue(7, 12)
        },
        { 
            stock: 'TATAMOTORS',
            party: 'Tata Sons Private Limited',
            category: 'Block',
            valueTraded: randomizeCrValue(25, 35),
            quantity: randomizeLValue(4, 8)
        },
        { 
            stock: 'INFY', 
            party: 'Infosys Foundation',
            category: 'Insider - Employee',
            valueTraded: randomizeCrValue(15, 25),
            quantity: randomizeLValue(1, 3)
        },
        { 
            stock: 'HDFCBANK', 
            party: 'HDFC Investments Limited',
            category: 'Bulk',
            valueTraded: randomizeCrValue(30, 50),
            quantity: randomizeLValue(3, 6)
        }
    ];
    
    // Generate 2-4 new dynamic entries for each request to simulate real-time updates
    const randomCount = Math.floor(Math.random() * 3) + 2; // 2-4 new entries
    const dynamicData = [];
    
    for (let i = 0; i < randomCount; i++) {
        const randomStock = dynamicStocks[Math.floor(Math.random() * dynamicStocks.length)];
        const txnType = Math.random() > 0.5 ? 'Buy' : 'Sell';
        const avgPrice = getRandomPrice(randomStock.stock);
        const holdingsChange = (Math.random() * 3).toFixed(2) + '%';
        
        dynamicData.push({
            stock: randomStock.stock,
            date: getCurrentDate(),
            party: randomStock.party,
            category: randomStock.category,
            txnType: txnType,
            avgPrice: avgPrice,
            valueTraded: randomStock.valueTraded,
            holdingsChange: holdingsChange,
            quantity: randomStock.quantity
        });
    }
    
    // Combine dynamic and base data
    return [...dynamicData, ...baseData];
}

// Helper function to get current date in the format DD-MMM-YYYY
function getCurrentDate() {
    const now = new Date();
    const day = now.getDate().toString().padStart(2, '0');
    const month = now.toLocaleString('default', { month: 'short' });
    const year = now.getFullYear();
    return `${day}-${month}-${year}`;
}

// Helper function to get random price based on stock
function getRandomPrice(stock) {
    switch (stock) {
        case 'RELIANCE':
            return (2700 + Math.random() * 100).toFixed(2);
        case 'TATAMOTORS':
            return (800 + Math.random() * 50).toFixed(2);
        case 'INFY':
            return (1400 + Math.random() * 100).toFixed(2);
        case 'HDFCBANK':
            return (1600 + Math.random() * 100).toFixed(2);
        default:
            return (1000 + Math.random() * 500).toFixed(2);
    }
}

// Helper function to generate random Cr values
function randomizeCrValue(min, max) {
    return (min + Math.random() * (max - min)).toFixed(2) + 'Cr';
}

// Helper function to generate random L values
function randomizeLValue(min, max) {
    return (min + Math.random() * (max - min)).toFixed(2) + 'L';
}

module.exports = router; 